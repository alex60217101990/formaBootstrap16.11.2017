# Tippy.js
[![Build Status](https://travis-ci.org/atomiks/tippyjs.svg?branch=master)](https://travis-ci.org/atomiks/tippyjs)

Tippy.js is a lightweight, vanilla JS tooltip library powered by Popper.js.

View the documentation and demo here: https://atomiks.github.io/tippyjs/

## Installation

See releases: https://github.com/atomiks/tippyjs/releases

It's also available on npm:
```
npm install --save tippy.js
```


